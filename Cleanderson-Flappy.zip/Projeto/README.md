# FLAPPY GAME

### Flappy bird game created using basic OpenGL capabilities.

To build this game:

```
mkdir build
```

```
cd build
```

```
cmake ..
```

```
make
```

```
./flappy
```
